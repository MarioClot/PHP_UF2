<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="botons">
                        <a href="<?php echo e(url('lab_406')); ?>">
                            <button class="contenidor_menu">
                                <img class="img_boto" src="<?php echo e(asset('assets/images/chemistry.svg')); ?>">
                                <span>LAB 406</span>
                            </button>
                        </a>
                        <button class="contenidor_menu">
                            <img class="img_boto" src="<?php echo e(asset('assets/images/chemistry.svg')); ?>">
                            <span>LAB 407</span>
                        </button>
                        <button class="contenidor_menu">
                            <img class="img_boto" src="<?php echo e(asset('assets/images/chemistry.svg')); ?>">
                            <span>REACTIUS LAB 406</span>
                        </button>
                        <button class="contenidor_menu">
                            <img class="img_boto" src="<?php echo e(asset('assets/images/chemistry.svg')); ?>">
                            <span>MAGATZEM SANITAT</span>
                        </button>
                        <a href="<?php echo e(url('usuaris')); ?>">
                            <button class="contenidor_menu">
                                <img style="padding-top: 5%" class="img_boto" src="<?php echo e(asset('assets/images/users.svg')); ?>">
                                <span>USUARIS</span>
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>