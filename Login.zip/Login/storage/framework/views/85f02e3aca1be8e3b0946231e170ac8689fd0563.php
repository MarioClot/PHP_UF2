<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Dashboard</div>

                    <div class="panel-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                            Aqui va tot lo del Lab 406
                        <table class="table-striped table-hover">
                                <tr>
                                    <th>ID</th>
                                    <th>Localitzacio</th>
                                    <th>Nom</th>
                                    <th>Quantitat inicial</th>
                                    <th>Quantitat actual</th>
                                    <th>Percentatge minim</th>
                                    <th>Proveidor</th>
                                    <th>Referencia proveidor</th>
                                    <th>Marca equip</th>
                                    <th>Nº lot</th>
                                </tr>
                            <?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($item->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->localitzacio); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->nom); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->quantitat_inicial); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->quantitat_actual); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->percentatge_minim); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->proveidor); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->referencia_proveidor); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->marca_equip); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->n_lot); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                        <!--?php dump($material) ?-->

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>