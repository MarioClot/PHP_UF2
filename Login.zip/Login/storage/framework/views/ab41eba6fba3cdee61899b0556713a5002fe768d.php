<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-heading">Editar: <?php echo e($item->nom); ?></div>

                        <div class="panel-body">
                            <form method="POST" action="prodmod/<?php echo e($item->id); ?>">
                            <table class="table-striped table-hover">
                                <tr>
                                    <th>Localitzacio</th>
                                    <th>Nom</th>
                                    <th>Quantitat inicial</th>
                                    <th>Quantitat actual</th>
                                    <th>Percentatge minim d'avís</th>
                                    <th>Proveidor</th>
                                    <th>Referencia proveidor</th>
                                    <th>Marca equip</th>
                                    <th>Nº lot</th>
                                </tr>

                                    <?php echo e(csrf_field()); ?>

                                <tr>

                                    <td>
                                        <input id="localitzacio" spellcheck="false" type="text" class="form-control" name="localitzacio" value="<?php echo e($item->localitzacio); ?>" required>
                                        <?php if($errors->has('localitzacio')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('localitzacio')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input id="nom" spellcheck="false" type="text" class="form-control" name="nom" value="<?php echo e($item->nom); ?>" required>
                                        <?php if($errors->has('nom')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('nom')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input id="quantitat_inicial" spellcheck="false" type="number" class="form-control" name="quantitat_inicial" value="<?php echo e($item->quantitat_inicial); ?>" required>
                                        <?php if($errors->has('quantitat_inicial')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('quantitat_inicial')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input id="quantitat_actual" spellcheck="false" type="number" class="form-control" name="quantitat_actual" value="<?php echo e($item->quantitat_actual); ?>" required>
                                        <?php if($errors->has('quantitat_actual')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('quantitat_actual')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input id="percentatge_minim" spellcheck="false" type="number" class="form-control" name="percentatge_minim" value="<?php echo e($item->percentatge_minim); ?>" required>
                                        <?php if($errors->has('percentatge_minim')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('percentatge_minim')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input id="proveidor" spellcheck="false" type="text" class="form-control" name="proveidor" value="<?php echo e($item->proveidor); ?>" required>
                                        <?php if($errors->has('proveidor')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('proveidor')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input id="referencia_proveidor" spellcheck="false" type="text" class="form-control" name="referencia_proveidor" value="<?php echo e($item->referencia_proveidor); ?>" required>
                                        <?php if($errors->has('referencia_proveidor')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('referencia_proveidor')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input id="marca_equip" spellcheck="false" type="text" class="form-control" name="marca_equip" value="<?php echo e($item->marca_equip); ?>" required>
                                        <?php if($errors->has('marca_equip')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('marca_equip')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input id="n_lot" spellcheck="false" type="text" class="form-control" name="n_lot" value="<?php echo e($item->n_lot); ?>" required>
                                        <?php if($errors->has('n_lot')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('n_lot')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="submit" class="btn btn-primary">
                                            Guarda
                                        </button>
                                    </td>
                                </tr>
                            </table>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>